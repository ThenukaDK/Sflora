-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2014 at 02:54 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sflora`
--
CREATE DATABASE `sflora` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sflora`;

-- --------------------------------------------------------

--
-- Table structure for table `sf_cart_temp`
--

CREATE TABLE IF NOT EXISTS `sf_cart_temp` (
  `user_id` varchar(50) NOT NULL,
  `purchase_id` varchar(50) NOT NULL,
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `amount` int(4) NOT NULL,
  `price` float NOT NULL,
  `totalPrice` float NOT NULL,
  `Image` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`,`purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_cart_temp`
--


-- --------------------------------------------------------

--
-- Table structure for table `sf_favourites`
--

CREATE TABLE IF NOT EXISTS `sf_favourites` (
  `user_id` varchar(50) NOT NULL,
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `extraDetails` varchar(50) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`user_id`,`mainCatogory`,`subCatogory`,`color`,`plantHeight`,`extraDetails`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_favourites`
--

INSERT INTO `sf_favourites` (`user_id`, `mainCatogory`, `subCatogory`, `color`, `plantHeight`, `extraDetails`, `Image`, `price`) VALUES
('0832ea6311bb8fe3fe43', 'Water Plant', 'Olu', 'White', 1, '', 'IMG_0700.jpg', 450),
('43bf640d4b6ccc23b153', 'Anthurium', 'LadyJen', 'Pink/green Bycolor', 1.5, '', 'IMG_2127.JPG', 1000),
('43bf640d4b6ccc23b153', 'Roses', 'Roses', 'Pale Orange', 1.5, '', 'DSC_0650.jpg', 180),
('43bf640d4b6ccc23b153', 'Water Plant', 'Olu', 'White', 1, '', 'IMG_0700.jpg', 450),
('0832ea6311bb8fe3fe43', 'Roses', 'Roses', 'white Orange', 1.5, '', 'IMG_0911.JPG', 180),
('0832ea6311bb8fe3fe43', 'Water Plant', 'Manel', 'Bluish Purple', 1, '', 'IMG_0705.jpg', 500),
('2cfa35fc2f57c5226c90', 'Orchid', 'Dendrobium', 'light purple', 3, '', 'IMG_0971.JPG', 650),
('2cfa35fc2f57c5226c90', 'Roses', 'Roses', 'Pale Orange', 1.5, '', 'DSC_0650.jpg', 180),
('2cfa35fc2f57c5226c90', 'Roses', 'Roses', 'pink', 1.5, '', 'IMG_0391.JPG', 180);

-- --------------------------------------------------------

--
-- Table structure for table `sf_fertilizer`
--

CREATE TABLE IF NOT EXISTS `sf_fertilizer` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(50) NOT NULL,
  `extraDetails` varchar(50) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_fertilizer`
--

INSERT INTO `sf_fertilizer` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Fertilizer', 'Carbonic', 100, 20, 0, 'Compost', 0, '', '1Kg', 'IMG_2375.jpg', '2014-11-02'),
('Fertilizer', 'Carbonic', 30, 14, 0, 'Kohu Bath', 0, '', '1Kg', 'IMG_2376.jpg', '2014-11-02'),
('Fertilizer', 'Carbonic', 50, 18, 0, 'Chopped Coconut husks(Pol leli)', 0, '', '1Kg', 'IMG_2377.jpg', '2014-11-02'),
('Fertilizer', 'Chemical', 30, 12, 0, 'K14', 0, '', '100g', 'IMG_2378.jpg', '2014-11-04'),
('Fertilizer', 'Chemical', 30, 7, 0, 'N Plus', 0, '', '100g', 'IMG_2379.jpg', '2014-11-04');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_aglonima`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_aglonima` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_aglonima`
--

INSERT INTO `sf_flowers_aglonima` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Aglonima', 'Aglonima', 200, 10, 0, 'Green/white inline', 1, '', '', 'IMG_2170.JPG', '2014-11-15'),
('Aglonima', 'Aglonima', 100, 8, 0, 'Dark green/white dotted', 1, '', '', 'IMG_2171.JPG', '2014-11-14'),
('Aglonima', 'Aglonima', 100, 9, 0, 'Ashy green', 1, '', '', 'IMG_2173.JPG', '2014-11-14'),
('Aglonima', 'Aglonima', 200, 3, 0, 'Green/red inline', 1, '', '', 'IMG_2174.JPG', '2014-11-13'),
('Aglonima', 'Aglonima', 200, 7, 0, 'Green/red dash', 1, '', '', 'IMG_2175.JPG', '2014-11-11'),
('Aglonima', 'Aglonima', 250, 3, 0, 'Green/ash inline', 1, '', '', 'IMG_2176.JPG', '2014-11-10'),
('Aglonima', 'Aglonima', 250, 5, 0, 'Green/light green inline', 1, '', '', 'IMG_2177.JPG', '2014-11-09'),
('Aglonima', 'Aglonima', 300, 8, 0, 'Green/Ashy dash', 1, '', '', 'IMG_2179.JPG', '2014-11-09'),
('Aglonima', 'Aglonima', 300, 11, 0, 'Green/White dash', 1, '', '', 'IMG_2181.JPG', '2014-11-08'),
('Aglonima', 'Aglonima', 150, 6, 0, 'Green/ash outline', 1, '', '', 'IMG_2183.JPG', '2014-11-07'),
('Aglonima', 'Aglonima', 350, 3, 0, 'Dark Green/white dash', 1, '', '', 'IMG_2185.JPG', '2014-11-04'),
('Aglonima', 'Aglonima', 400, 7, 0, 'Green/white strip', 1, '', '', 'IMG_2187.JPG', '2014-11-02'),
('Aglonima', 'Aglonima', 400, 8, 0, 'Green/ash strip', 1, '', '', 'IMG_2189.JPG', '2014-10-31'),
('Aglonima', 'Aglonima', 350, 16, 0, 'Green/pink outline', 1, '', '', 'IMG_2191.JPG', '2014-10-29'),
('Aglonima', 'Aglonima', 300, 10, 0, 'Red/Green dash', 1, '', '', 'IMG_2193.JPG', '2014-10-26'),
('Aglonima', 'Aglonima', 450, 3, 0, 'White/green dash', 1, '', '', 'IMG_2195.JPG', '2014-10-18'),
('Aglonima', 'Aglonima', 400, 8, 0, 'Green/yellow inline', 1, '', '', 'IMG_2197.JPG', '2014-10-15'),
('Aglonima', 'Aglonima', 400, 5, 0, 'Ash/green dash', 1, '', '', 'IMG_2201.JPG', '2014-10-12'),
('Aglonima', 'Aglonima', 400, 6, 0, 'Green/yellow strip', 1, '', '', 'IMG_2203.JPG', '2014-10-12'),
('Aglonima', 'Aglonima', 350, 7, 0, 'Dark green/pink dash', 1, '', '', 'IMG_2205.JPG', '2014-10-10'),
('Aglonima', 'Aglonima', 400, 1, 0, 'Green/red outline', 1, '', '', 'IMG_2207.JPG', '2014-10-09'),
('Aglonima', 'Aglonima', 400, 5, 0, 'Dark green/yellow dash', 1, '', '', 'IMG_2209.JPG', '2014-10-09');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_anthurium`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_anthurium` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_anthurium`
--

INSERT INTO `sf_flowers_anthurium` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Anthurium', 'LadyJen', 1000, 19, 1, 'Pink/green Bycolor', 1.5, '', '', 'IMG_2128.JPG', '2014-11-15'),
('Anthurium', 'LadyJen', 450, 6, 1, 'Pale Pink', 1.25, '', '', 'IMG_2128.JPG', '2014-11-13'),
('Anthurium', 'LadyJen', 450, 6, 1, 'white', 0.9, '', '', 'IMG_2129.JPG', '2014-11-11'),
('Anthurium', 'LadyJen', 450, 9, 1, 'dark pink', 1, '', '', 'IMG_2131.JPG', '2014-11-10'),
('Anthurium', 'LadyJen', 450, 4, 1, 'pink', 1, '', '', 'IMG_2132.JPG', '2014-11-07'),
('Anthurium', 'LadyJen', 450, 8, 1, 'pale red', 2.5, '', '', 'IMG_2133.JPG', '2014-11-06'),
('Anthurium', 'LadyJen', 1500, 7, 1, 'orange', 2.5, '', '', 'IMG_2134.JPG', '2014-11-05'),
('Anthurium', 'LadyJen', 1500, 15, 1, 'Red/Green Bycolor', 2.5, '', '', 'IMG_2135.JPG', '2014-11-03'),
('Anthurium', 'LadyJen', 1500, 6, 1, 'cherry red', 2.5, '', '', 'IMG_2136.JPG', '2014-11-01'),
('Anthurium', 'LadyJen', 500, 12, 1, 'pink champion', 1, '', '', 'IMG_2137.JPG', '2014-10-30'),
('Anthurium', 'CutFlower', 1000, 10, 1, 'Grace', 2.5, '', '', 'IMG_2139.JPG', '2014-10-27'),
('Anthurium', 'CutFlower', 500, 11, 1, 'Terra Brown', 2.5, '', '', 'IMG_2140.JPG', '2014-10-21'),
('Anthurium', 'CutFlower', 1500, 6, 1, 'Rapido purple/pink', 3, '', '', 'IMG_2141.JPG', '2014-10-19'),
('Anthurium', 'LadyJen', 1000, 10, 1, 'dark purple', 2.5, '', '', 'IMG_2142.JPG', '2014-10-11'),
('Anthurium', 'CutFlower', 1000, 10, 1, 'dark pink', 2.5, '', '', 'IMG_2143.JPG', '2014-10-03'),
('Anthurium', 'CutFlower', 500, 17, 1, 'white rose', 2, '', '', 'IMG_2144.JPG', '2014-10-02'),
('Anthurium', 'CutFlower', 1000, 10, 1, 'pink', 3, '', '', 'IMG_2145.JPG', '2014-10-02'),
('Anthurium', 'CutFlower', 500, 8, 1, 'white', 2.5, '', '', 'IMG_2146.JPG', '2014-09-30'),
('Anthurium', 'CutFlower', 1000, 5, 1, 'dark red', 3, '', '', 'IMG_2147.JPG', '2014-09-28'),
('Anthurium', 'CutFlower', 1000, 4, 1, 'white pink nob', 3, '', '', 'IMG_2148.JPG', '2014-11-21'),
('Anthurium', 'CutFlower', 600, 3, 1, 'Pale Pink', 2.5, '', '', 'IMG_2149.JPG', '2014-09-17'),
('Anthurium', 'CutFlower', 1000, 6, 1, 'nobless', 3, '', '', 'IMG_2150.JPG', '2014-09-16'),
('Anthurium', 'CutFlower', 1000, 5, 1, 'choco', 3, '', '', 'IMG_2152.JPG', '2014-09-16'),
('Anthurium', 'CutFlower', 1000, 11, 1, 'Green Smerilda', 2, '', '', 'IMG_2153.JPG', '2014-09-16'),
('Anthurium', 'CutFlower', 1000, 8, 1, 'blood red', 3, '', '', 'IMG_2154.JPG', '2014-09-14'),
('Anthurium', 'CutFlower', 500, 5, 1, 'coca cola', 2, '', '', 'IMG_2155.JPG', '2014-09-14'),
('Anthurium', 'CutFlower', 500, 10, 1, 'Evo red', 3, '', '', 'IMG_2156.JPG', '2014-09-13'),
('Anthurium', 'CutFlower', 500, 5, 1, 'butterfly red/green', 2, '', '', 'IMG_2157.JPG', '2014-09-12'),
('Anthurium', 'CutFlower', 500, 6, 1, 'pigmin', 1, '', '', 'IMG_2158.JPG', '2014-09-12');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_colias`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_colias` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_colias`
--

INSERT INTO `sf_flowers_colias` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Colias', 'Colias', 250, 3, 0, 'purple/red', 1, '', '', 'IMG_2211.JPG', '2014-11-15'),
('Colias', 'Colias', 250, 8, 0, 'Green/pink inline', 1, '', '', 'IMG_2213.JPG', '2014-11-13'),
('Colias', 'Colias', 250, 3, 0, 'dark purple', 1, '', '', 'IMG_2215.JPG', '2014-11-12'),
('Colias', 'Colias', 250, 5, 0, 'Green/brown inline', 1, 'No data', 'No data', 'IMG_2221.JPG', '2014-11-10'),
('Colias', 'Colias', 250, 9, 0, 'purple/green outline', 1, '', '', 'IMG_2224.JPG', '2014-11-04'),
('Colias', 'Colias', 250, 10, 0, 'Green/white inline', 1, '', '', 'IMG_2225.JPG', '2014-11-08'),
('Colias', 'Colias', 250, 5, 0, 'purple/green inline', 1, '', '', 'IMG_2229.JPG', '2014-11-08'),
('Colias', 'Colias', 250, 4, 0, 'Brown/green inline', 1, '', '', 'IMG_2231.JPG', '2014-11-04'),
('Colias', 'Colias', 250, 7, 0, 'Green/inline purple', 1, '', '', 'IMG_2232.JPG', '2014-11-02'),
('Colias', 'Colias', 250, 9, 0, 'purple/ash green inline', 1, '', '', 'IMG_2233.JPG', '2014-11-01'),
('Colias', 'Colias', 60, 1, 0, 'Green/purple dashed', 1, '', '', 'IMG_2234.JPG', '2014-10-28'),
('Colias', 'Colias', 60, 3, 0, 'purple/white outline', 1, '', '', 'IMG_2235.JPG', '2014-10-19'),
('Colias', 'Colias', 60, 5, 0, 'Green mix purple', 1, '', '', 'IMG_2236.JPG', '2014-10-11');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_decorative`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_decorative` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_decorative`
--

INSERT INTO `sf_flowers_decorative` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Decorative', 'unknown', 250, 2, 0, 'Green/white inline', 1.5, '', '', 'IMG_2172.JPG', '2014-11-15'),
('Decorative', 'Croton', 650, 2, 0, 'Green/yellow inline', 3, '', '', 'IMG_2237.JPG', '2014-11-14'),
('Decorative', 'Croton', 650, 1, 0, 'Green/red inline', 3.5, '', '', 'IMG_2238.JPG', '2014-11-13'),
('Decorative', 'Croton', 650, 2, 0, 'Red/Green/Yellow', 3, '', '', 'IMG_2239.JPG', '2014-11-11'),
('Decorative', 'Croton', 650, 2, 0, 'yellow/Green dash', 3.5, '', '', 'IMG_2240.JPG', '2014-11-10'),
('Decorative', 'Croton', 650, 2, 0, 'Green/yellow line', 2.5, '', '', 'IMG_2241.JPG', '2014-11-10'),
('Decorative', 'Croton', 650, 3, 0, 'Green/red dash', 2.5, '', '', 'IMG_2242.JPG', '2014-11-09'),
('Decorative', 'Croton', 650, 4, 0, 'Green/yellow strip', 1.5, '', '', 'IMG_2243.JPG', '2014-11-08'),
('Decorative', 'Croton', 650, 1, 0, 'Red/Green/Yellow strip', 3, '', '', 'IMG_2244.JPG', '2014-11-06'),
('Decorative', 'Croton', 500, 5, 0, 'Green/purple', 1.5, '', '', 'IMG_2245.JPG', '2014-11-03'),
('Decorative', 'Sandriana', 300, 10, 0, 'light Green', 2, '', '', 'IMG_2262.JPG', '2014-11-02'),
('Decorative', 'Calathia', 400, 10, 0, 'Dark green/ash strips', 1.5, '', '', 'IMG_2263.JPG', '2014-11-02'),
('Decorative', 'Bird Nest', 250, 11, 0, 'Green', 1, '', '', 'IMG_2264.JPG', '2014-11-01'),
('Decorative', 'Calathia', 300, 5, 0, 'light Green/Dark green strip', 0.5, '', '', 'IMG_2265.JPG', '2014-11-01'),
('Decorative', 'Begonia', 250, 2, 0, 'Ash/Purple dash', 0.5, '', '', 'IMG_2266.JPG', '2014-10-31'),
('Decorative', 'Begonia', 350, 4, 0, 'purple/ash green dotted', 0.5, '', '', 'IMG_2267.JPG', '2014-10-31'),
('Decorative', 'Begonia', 300, 2, 0, 'white/purple inline', 0.5, '', '', 'IMG_2267.JPG', '2014-10-30'),
('Decorative', 'Begonia', 250, 3, 0, 'light Green', 1, '', '', 'IMG_2269.JPG', '2014-10-29'),
('Decorative', 'Begonia', 200, 6, 0, 'Purple', 0.5, '', '', 'IMG_2270.JPG', '2014-10-27'),
('Decorative', 'Begonia', 250, 6, 0, 'Green/white inline', 1, '', '', 'IMG_2271.JPG', '2014-10-26'),
('Decorative', 'Begonia', 250, 4, 0, 'Green', 1.5, '', '', 'IMG_2272.JPG', '2014-10-25'),
('Decorative', 'unknown', 300, 4, 0, 'Ash/green dash', 1.5, '', '', 'IMG_2273.JPG', '2014-10-25'),
('Decorative', 'unknown', 450, 6, 0, 'Purple', 1.5, '', '', 'IMG_2274.JPG', '2014-10-24'),
('Decorative', 'unknown', 300, 5, 0, 'Green/pink dashed', 1, '', '', 'IMG_2275.JPG', '2014-10-22'),
('Decorative', 'unknown', 500, 10, 0, 'Dark green', 2, '', '', 'IMG_2276.JPG', '2014-10-21'),
('Decorative', 'Codiline', 350, 3, 0, 'Green/white outline', 3, '', '', 'IMG_2277.JPG', '2014-10-20'),
('Decorative', 'Codiline', 500, 4, 0, 'Green/light green', 2, '', '', 'IMG_2278.JPG', '2014-10-19'),
('Decorative', 'Codiline', 500, 8, 0, 'Red/purple', 3.5, '', '', 'IMG_2279.JPG', '2014-10-18'),
('Decorative', 'Calathia', 500, 6, 0, 'Dark Green/white dash', 2, '', '', 'IMG_2280.JPG', '2014-10-18'),
('Decorative', 'Calathia', 500, 3, 0, 'Green squares', 1.5, '', '', 'IMG_2281.JPG', '2014-10-17'),
('Decorative', 'Calathia', 500, 5, 0, 'light Green/Dark green dash', 3, '', '', 'IMG_2282.JPG', '2014-10-15'),
('Decorative', 'unknown', 500, 5, 0, 'Dark Green/white inline', 1.5, '', '', 'IMG_2283.JPG', '2014-10-14'),
('Decorative', 'Calathia', 350, 3, 0, 'light Green/white inline', 1.5, '', '', 'IMG_2284.JPG', '2014-10-12'),
('Decorative', 'Calathia', 200, 8, 0, 'Ash/Dark green dash', 1.5, '', '', 'IMG_2285.JPG', '2014-10-12'),
('Decorative', 'Leeya', 1200, 2, 0, 'Maroon', 4, '', '', 'IMG_2286.JPG', '2014-10-11'),
('Decorative', 'furnace', 350, 3, 0, 'Green', 0, '', '', 'IMG_2287.JPG', '2014-10-10'),
('Decorative', 'furnace', 350, 4, 0, 'light Green', 1.5, '', '', 'IMG_2288.JPG', '2014-10-08'),
('Decorative', 'unknown', 450, 3, 0, 'Green/ash inline', 0.5, '', '', 'IMG_2289.JPG', '2014-10-07'),
('Decorative', 'unknown', 450, 3, 0, 'light Green/white outline', 1, '', '', 'IMG_2290.JPG', '2014-10-06'),
('Decorative', 'God sofiana', 400, 5, 0, 'Green/White dash', 2.5, '', '', 'IMG_2291.JPG', '2014-10-05'),
('Decorative', 'unknown', 500, 8, 0, 'Green/yellow inline', 3, '', '', 'IMG_2292.JPG', '2014-10-04'),
('Decorative', 'Croton', 450, 3, 0, 'Dark green/yellow inline', 2, '', '', 'IMG_2293.JPG', '2014-10-04'),
('Decorative', 'unknown', 250, 3, 0, 'Green/orange inline', 1, '', '', 'IMG_2294.JPG', '2014-10-03'),
('Decorative', 'Eyevy', 800, 5, 0, 'White/green dash', 1, '', '', 'IMG_2295.JPG', '2014-10-02'),
('Decorative', 'Creepers', 700, 8, 0, 'Ashy green', 3, '', '', 'IMG_2296.JPG', '2014-09-30'),
('Decorative', 'Creepers', 500, 6, 0, 'Green long leave', 3, '', '', 'IMG_2297.JPG', '2014-09-29'),
('Decorative', 'Creepers', 600, 8, 0, 'light Green/yellow dash', 2, '', '', 'IMG_2298.JPG', '2014-09-29'),
('Decorative', 'unknown', 800, 4, 0, 'light Green/white bubble', 1.5, '', '', 'IMG_2299.JPG', '2014-09-28'),
('Decorative', 'unknown', 700, 2, 0, 'Ashy green/yellow bubbles', 2, '', '', 'IMG_2300.JPG', '2014-09-28'),
('Decorative', 'Codiline', 400, 8, 0, 'Purple/pink ', 1.5, '', '', 'IMG_2301.JPG', '2014-09-27'),
('Decorative', 'unknown', 400, 4, 1, 'light Green/brown flower', 1, '', '', 'IMG_2303.JPG', '2014-09-26'),
('Decorative', 'Creepers', 400, 3, 0, 'Green/pink dashed', 1.5, '', '', 'IMG_2304.JPG', '2014-09-19'),
('Decorative', 'Red Mukunuwanne', 300, 10, 0, 'Red', 2, '', '', 'IMG_2305.JPG', '2014-09-18'),
('Decorative', 'Medlina', 800, 2, 1, 'Green/Pink flower', 3, '', '', 'IMG_2306.JPG', '2014-09-17'),
('Decorative', 'Polishia', 400, 6, 0, 'Ashy green/white', 2.5, '', '', 'IMG_2307.JPG', '2014-09-16'),
('Decorative', 'Cyprus', 1000, 5, 0, 'Green', 2.5, '', '', 'IMG_2308.JPG', '2014-09-15'),
('Decorative', 'unknown', 200, 8, 0, 'light Green/yellow', 1, '', '', 'IMG_2309.JPG', '2014-09-14'),
('Decorative', 'Crystina', 500, 3, 0, 'Green', 2, '', '', 'IMG_2310.JPG', '2014-09-13'),
('Decorative', 'Crystina', 800, 3, 0, 'Green/Red', 2, '', '', 'IMG_2311.JPG', '2014-09-13'),
('Decorative', 'Creepers', 400, 5, 0, 'Green short leave', 1.5, '', '', 'IMG_2312.JPG', '2014-09-12'),
('Decorative', 'Creepers', 500, 9, 0, 'light Green', 3, '', '', 'IMG_2313.JPG', '2014-09-11'),
('Decorative', 'Calathia', 250, 4, 0, 'Green/dark green dash', 1, '', '', 'IMG_2314.JPG', '2014-09-10'),
('Decorative', 'Shamia', 500, 8, 0, 'Green', 2.5, '', '', 'IMG_2315.JPG', '2014-09-09'),
('Decorative', 'Sandriana', 300, 6, 0, 'light Green/white inline', 2.5, '', '', 'IMG_2316.JPG', '2014-09-08'),
('Decorative', 'Indian Madu', 800, 2, 0, 'Dark green', 1, '', '', 'IMG_2317.JPG', '2014-09-08'),
('Decorative', 'Exora', 500, 2, 1, 'yellow', 3, '', '', 'IMG_2318.JPG', '2014-09-07'),
('Decorative', 'Exora', 500, 6, 1, 'pink', 2.5, '', '', 'IMG_2319.JPG', '2014-09-06'),
('Decorative', 'Exora', 500, 8, 1, 'Red', 2, '', '', 'IMG_2320.JPG', '2014-09-05'),
('Decorative', 'Yesterday To Tommorow', 500, 3, 1, 'purple/white', 2.5, '', '', 'IMG_2321.JPG', '2014-09-05'),
('Decorative', 'Plumbego', 300, 8, 1, 'Bluish Purple', 1.5, '', '', 'IMG_2322.JPG', '2014-09-04'),
('Decorative', 'ButterCup(Diplednia)', 600, 7, 1, 'White', 3, '', '', 'IMG_2323.JPG', '2014-09-02'),
('Decorative', 'Iwata', 400, 5, 1, 'white', 2.5, '', '', 'IMG_2324.JPG', '2014-09-01'),
('Decorative', 'unknown', 500, 4, 1, 'light purple', 3.5, '', '', 'IMG_2325.JPG', '2014-08-31'),
('Decorative', 'Bridle Wale', 500, 2, 1, 'White', 2.5, '', '', 'IMG_2326.JPG', '2014-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_farms`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_farms` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_farms`
--

INSERT INTO `sf_flowers_farms` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Farms', 'Wichia Gold', 2500, 3, 0, 'Green/light green', 3.5, '', '', 'IMG_2334.JPG', '2014-11-15'),
('Farms', 'Kane Farm', 500, 4, 0, 'Green', 3, '', '', 'IMG_2335.JPG', '2014-11-01'),
('Farms', 'Kenthia Farm', 250, 5, 0, 'Green/light green', 3, '', '', 'IMG_2336.JPG', '2014-10-31'),
('Farms', 'Red Farm', 250, 6, 0, 'Green/red inline', 3, '', '', 'IMG_2337.JPG', '2014-10-26'),
('Farms', 'Traingular', 1200, 3, 0, 'Green', 4, '', '', 'IMG_2338.JPG', '2014-10-16'),
('Farms', 'Fox Tail', 1200, 5, 0, 'Green', 4, '', '', 'IMG_2339.JPG', '2014-10-14');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_hanging`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_hanging` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` decimal(5,0) NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_hanging`
--

INSERT INTO `sf_flowers_hanging` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Hanging', 'Fernce', '300', 1, 0, 'light Green', 0.5, '', '', 'IMG_2247.JPG', '2014-11-16'),
('Hanging', 'unknown', '350', 2, 0, 'White/green outline', 1, '', '', 'IMG_2248.JPG', '2014-11-15'),
('Hanging', 'Aglonima', '250', 4, 0, 'White/green dash', 1, '', '', 'IMG_2249.JPG', '2014-11-13'),
('Hanging', 'unknown', '250', 2, 0, 'Green/white outline longleave', 0.5, '', '', 'IMG_2250.JPG', '2014-11-11'),
('Hanging', 'unknown', '200', 8, 0, 'Ashy green', 0.5, '', '', 'IMG_2251.JPG', '2014-11-12'),
('Hanging', 'unknown', '300', 9, 0, 'light Green/ash inline', 0.5, '', '', 'IMG_2252.JPG', '2014-11-10'),
('Hanging', 'unknown', '350', 5, 1, 'Dark green/red flower', 0.5, '', '', 'IMG_2253.JPG', '2014-11-09'),
('Hanging', 'unknown', '250', 3, 0, 'purple/ash green inline', 0.5, '', '', 'IMG_2254.JPG', '2014-11-01'),
('Hanging', 'Million hearts', '350', 9, 0, 'Dark green', 0.5, '', '', 'IMG_2255.JPG', '2014-10-31'),
('Hanging', 'unknown', '250', 3, 0, 'Dark green/purple backside', 0.5, '', '', 'IMG_2256.JPG', '2014-10-30'),
('Hanging', 'Begonia', '200', 6, 0, 'Ashy green', 0.5, '', '', 'IMG_2257.JPG', '2014-10-28'),
('Hanging', 'unknown', '200', 12, 0, 'light Green grass', 0.5, '', '', 'IMG_2258.JPG', '2014-10-27'),
('Hanging', 'unknown', '300', 4, 1, 'Dark green/white flower', 1, '', '', 'IMG_2259.JPG', '2014-10-26'),
('Hanging', 'unknown', '300', 5, 0, 'Dark Green/white dash', 0.5, '', '', 'IMG_2261.JPG', '2014-10-24');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_orchid`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_orchid` (
  `mainCatogory` varchar(500) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_orchid`
--

INSERT INTO `sf_flowers_orchid` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Orchid', 'Dendrobium', 650, 5, 1, 'light Bown purple inline', 3, '', '', 'IMG_2159.JPG', '2014-11-16'),
('Orchid', 'Dendrobium', 650, 6, 1, 'white/purple outline', 3, '', '', 'IMG_2160.JPG', '2014-11-15'),
('Orchid', 'Dendrobium', 650, 4, 1, 'dark purple/Inline Yellow', 3, '', '', 'IMG_2163.JPG', '2014-11-13'),
('Orchid', 'Dendrobium', 650, 5, 1, 'light purple', 3, '', '', 'IMG_0971.JPG', '2014-11-12'),
('Orchid', 'Dendrobium', 650, 8, 1, 'dark purple', 2.5, '', '', 'IMG_1011.JPG', '2014-11-11'),
('Orchid', 'Dendrobium', 700, 6, 1, 'dark purple/outline white', 3, '', '', 'IMG_1195.JPG', '2014-11-10'),
('Orchid', 'Dendrobium', 700, 4, 1, 'light purple/outline white', 3, '', '', 'IMG_1197.JPG', '2014-11-09'),
('Orchid', 'Dendrobium', 700, 2, 1, 'white', 3, '', '', 'IMG_1199.JPG', '2014-11-08'),
('Orchid', 'Dendrobium', 1000, 4, 1, 'Royal banana/Yellow', 2, '', '', 'IMG_1198.JPG', '2014-11-05'),
('Orchid', 'Ground Orchid', 350, 6, 1, 'Purple/yellow outline', 3, '', '', 'IMG_2165.JPG', '2014-11-01'),
('Orchid', 'Ground Orchid', 350, 4, 1, 'dark purple/Inline white', 3, '', '', 'IMG_2166.JPG', '2014-10-31'),
('Orchid', 'Ground Orchid', 350, 5, 1, 'light purple', 3.5, '', '', 'IMG_2168.JPG', '2014-10-29'),
('Orchid', 'Ground Orchid', 350, 4, 1, 'light purple/yellow outline', 2.5, '', '', 'IMG_2167.JPG', '2014-10-27');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_roses`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_roses` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_roses`
--

INSERT INTO `sf_flowers_roses` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Roses', 'Roses', 180, -1, 1, 'Pale Orange', 1.5, '', '', 'DSC_0650.jpg', '2014-11-16'),
('Roses', 'Roses', 180, 2, 1, 'yellow', 1.5, '', '', 'DSCF0607.JPG', '2014-11-13'),
('Roses', 'Roses', 180, 3, 1, 'blood red', 1.5, '', '', 'IMG_0369.JPG', '2014-11-12'),
('Roses', 'Roses', 180, 5, 1, 'pink', 1.5, '', '', 'IMG_0391.JPG', '2014-11-10'),
('Roses', 'Roses', 180, 4, 1, 'dark pink', 1.5, '', '', 'IMG_0567.JPG', '2014-11-09'),
('Roses', 'Roses', 180, 3, 1, 'white pink', 1.5, '', '', 'IMG_0650.JPG', '2014-11-08'),
('Roses', 'Roses', 180, 6, 1, 'white Orange', 1.5, '', '', 'IMG_0911.JPG', '2014-11-05'),
('Roses', 'Roses', 180, 2, 1, 'pink orange', 1.5, '', '', 'IMG_0992.JPG', '2014-11-02'),
('Roses', 'Roses', 180, 8, 1, 'Red pink', 1.5, '', '', 'IMG_1138.JPG', '2014-10-31'),
('Roses', 'Roses', 180, 4, 1, 'White yellow', 1.5, '', '', 'IMG_1148.JPG', '2014-10-28'),
('Roses', 'Roses', 180, 7, 1, 'white', 1.5, '', '', 'IMG_1176.JPG', '2014-10-25'),
('Roses', 'Roses', 180, 4, 1, 'Pale Pink', 1.5, '', '', 'IMG_1185.JPG', '2014-10-18'),
('Roses', 'Roses', 180, 5, 1, 'creamy pink', 1.5, '', '', 'IMG_1201.JPG', '2014-10-16'),
('Roses', 'Roses', 180, 5, 1, 'creamy white', 1.5, '', '', 'IMG_1369.JPG', '2014-10-13'),
('Roses', 'Roses', 180, 6, 1, 'Maroon', 1.5, '', '', 'IMG_1371.JPG', '2014-10-10'),
('Roses', 'Roses', 180, 8, 1, 'orange', 1.5, '', '', 'IMG_1401.JPG', '2014-10-01');

-- --------------------------------------------------------

--
-- Table structure for table `sf_flowers_water`
--

CREATE TABLE IF NOT EXISTS `sf_flowers_water` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float(5,0) NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(1000) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_flowers_water`
--

INSERT INTO `sf_flowers_water` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Water Plant', 'Manel', 500, 0, 1, 'Bluish Purple', 1, '', '', 'IMG_0705.jpg', '2014-11-21'),
('Water Plant', 'Olu', 450, 2, 1, 'White', 1, '', '', 'IMG_0700.jpg', '2014-11-23');

-- --------------------------------------------------------

--
-- Table structure for table `sf_messages`
--

CREATE TABLE IF NOT EXISTS `sf_messages` (
  `messageId` varchar(50) NOT NULL,
  `userId` varchar(50) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `reply` varchar(1000) DEFAULT NULL,
  `replyDateTime` datetime DEFAULT NULL,
  `dateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`messageId`,`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_messages`
--

INSERT INTO `sf_messages` (`messageId`, `userId`, `userName`, `subject`, `message`, `reply`, `replyDateTime`, `dateTime`) VALUES
('54848cdba695b', '0832ea6311bb8fe3fe43', 'Thenuka', 'Getting Advice', 'How do I water anthurium flowers? How often?', 'Water 1L of water twice a day.', '0000-00-00 00:00:00', '2014-12-07 17:22:35'),
('548683b4cc945', 'a92de3a49089036c4029', 'ruwan', 'Complain about a flower!', 'I bought a roses and after 2 days yellow spots started to appear. Y is that? ugniunuhbuygbygbyg bgg ygby gyng gnnf8 8n8h 8hn8fh 8hn8uh duhewgy uyuwch ', 'You should spray fungus liquid', '0000-00-00 00:00:00', '2014-12-09 05:08:04'),
('5489a58ad1fc3', '2cfa35fc2f57c5226c90', 'nalin', 'Problem about a flower', 'I dont know how to put fertilizer to orchids', 'No fertilizers are perticulalry needed. Just spray anti fungus chemicals twice a week.', '0000-00-00 00:00:00', '2014-12-11 14:09:14');

-- --------------------------------------------------------

--
-- Table structure for table `sf_order`
--

CREATE TABLE IF NOT EXISTS `sf_order` (
  `user_id` varchar(50) NOT NULL,
  `purchase_id` varchar(50) NOT NULL,
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `amount` int(5) NOT NULL,
  `price` float NOT NULL,
  `totalPrice` float NOT NULL,
  `orderdDate` date NOT NULL,
  `Image` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`,`purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_order`
--

INSERT INTO `sf_order` (`user_id`, `purchase_id`, `mainCatogory`, `subCatogory`, `color`, `amount`, `price`, `totalPrice`, `orderdDate`, `Image`) VALUES
('0832ea6311bb8fe3fe43', 'f1ca2d3b47f0e72a279b0e8db63f43bc', 'Roses', 'Roses', 'white Orange', 3, 180, 540, '2014-11-20', 'IMG_0911.JPG'),
('0832ea6311bb8fe3fe43', '9e549c50032b9a124090f705eee94f25', 'Hanging', 'Fernce', 'light Green', 2, 300, 600, '2014-11-20', 'IMG_2247.JPG'),
('0832ea6311bb8fe3fe43', '6917891e5eb29804b3854409a2e6011a', 'Decorative', 'Croton', 'Dark green/yellow inline', 2, 450, 900, '2014-11-20', 'IMG_2293.JPG'),
('a92de3a49089036c4029', '12331eab2837fea15950c546982bb8aa', 'Hanging', 'unknown', 'Dark green/red flower', 2, 350, 700, '2014-11-20', 'IMG_2253.JPG'),
('a92de3a49089036c4029', 'bb4b80522998b22cb4a15175f10c9a5c', 'Aglonima', 'Aglonima', 'Green/red inline', 1, 200, 200, '2014-11-20', 'IMG_2174.JPG'),
('a92de3a49089036c4029', 'e5ffa13aec616c56510369295c013bdc', 'Roses', 'Roses', 'pink', 2, 180, 360, '2014-11-20', 'IMG_0391.JPG'),
('a92de3a49089036c4029', '02fa875571aa5329a8836d5578ce6471', 'Orchid', 'Dendrobium', 'Royal banana/Yellow', 1, 1000, 1000, '2014-11-20', 'IMG_1198.JPG'),
('d22dee9a200b6ab060f4', '13f0a223c316987d5ce15f068b51990a', 'Roses', 'Roses', 'Pale Orange', 2, 180, 360, '2014-11-20', 'DSC_0650.jpg'),
('d22dee9a200b6ab060f4', '618ea6d2d626066ad3d6c17d97efd6b0', 'Orchid', 'Ground Orchid', 'light purple', 2, 350, 700, '2014-11-20', 'IMG_2168.JPG'),
('d22dee9a200b6ab060f4', 'd785b756f8597db99ef8448c47a4324c', 'Hanging', 'Fernce', 'light Green', 1, 300, 300, '2014-11-20', 'IMG_2247.JPG'),
('43bf640d4b6ccc23b153', 'b8d0a66dd2bd486fd251d5fb2e6a6cb0', 'Decorative', 'Sandriana', 'light Green', 3, 300, 900, '2014-11-20', 'IMG_2262.JPG'),
('43bf640d4b6ccc23b153', '2720d59d3324b795ea85292e53b6d0a0', 'Farms', 'Wichia Gold', 'Green/light green', 1, 2500, 2500, '2014-11-20', 'IMG_2334.JPG'),
('43bf640d4b6ccc23b153', 'ad6d8830345bbbae64b8a0b3c270d180', 'Anthurium', 'LadyJen', 'dark purple', 2, 1000, 2000, '2014-11-20', 'IMG_2142.JPG'),
('153be4f2df659f2d066f', '65baac65413853ae686629fbe071dd4b', 'Decorative', 'Calathia', 'light Green/Dark green dash', 1, 500, 500, '2014-11-20', 'IMG_2282.JPG'),
('153be4f2df659f2d066f', 'efa7c692b5f6cf9d78265d627aecd0b3', 'Colias', 'Colias', 'purple/ash green inline', 1, 250, 250, '2014-11-20', 'IMG_2233.JPG'),
('0832ea6311bb8fe3fe43', '959605682441df1dbb005cb67b086803', 'Hanging', 'Fernce', 'light Green', 1, 300, 300, '2014-12-04', 'IMG_2247.JPG'),
('0832ea6311bb8fe3fe43', '890738e4282dcc9a03b35b0d44a6368b', 'Hanging', 'unknown', 'White/green outline', 2, 350, 700, '2014-12-05', 'IMG_2248.JPG'),
('0832ea6311bb8fe3fe43', '3fcc611219edc7a6c9145ae92379a9e3', 'Aglonima', 'Aglonima', 'Green/red inline', 1, 200, 200, '2014-12-05', 'IMG_2174.JPG'),
('2cfa35fc2f57c5226c90', '97cf5a13daba4b248b32eee6537d5c1a', 'Water Plant', 'Manel', 'Bluish Purple', 1, 500, 500, '2014-12-11', 'IMG_0705.jpg'),
('2cfa35fc2f57c5226c90', '61dfc9edca2308bd216993186d750295', 'Roses', 'Roses', 'Pale Orange', 2, 180, 360, '2014-12-11', 'DSC_0650.jpg'),
('0832ea6311bb8fe3fe43', 'd8e0ed1d9ad0407df813bcea1333af16', 'Water Plant', 'Olu', 'White', 2, 450, 900, '2014-12-04', 'IMG_0700.jpg'),
('0832ea6311bb8fe3fe43', '8be0d3c7030e14ed900cc03a7fd5206f', 'Roses', 'Roses', 'yellow', 1, 180, 180, '2014-12-02', 'DSCF0607.JPG'),
('0832ea6311bb8fe3fe43', '5b9828a85647218988431041b8fcaa39', 'Water Plant', 'Olu', 'White', 1, 450, 450, '2014-12-01', 'IMG_0700.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sf_pots`
--

CREATE TABLE IF NOT EXISTS `sf_pots` (
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `stock` int(5) NOT NULL,
  `haveFlower` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `climateCondition` varchar(1000) NOT NULL,
  `extraDetails` varchar(50) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `addedDate` date NOT NULL,
  PRIMARY KEY (`mainCatogory`,`subCatogory`,`color`,`plantHeight`,`extraDetails`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_pots`
--

INSERT INTO `sf_pots` (`mainCatogory`, `subCatogory`, `price`, `stock`, `haveFlower`, `color`, `plantHeight`, `climateCondition`, `extraDetails`, `Image`, `addedDate`) VALUES
('Pots', 'Plastic', 50, 10, 0, 'Black', 5, '', '11.2', 'IMG_2362.jpg', '2014-11-02'),
('Pots', 'Plastic', 80, 14, 0, 'Black', 8, '', '9.9', 'IMG_2363.jpg', '2014-11-03'),
('Pots', 'Plastic', 30, 12, 0, 'Black', 3.5, '', '4.7', 'IMG_2365.jpg', '2014-11-04'),
('Pots', 'Plastic', 10, 8, 0, 'Black', 3, '', '3.5', 'IMG_2366.jpg', '2014-11-07'),
('Pots', 'Plastic', 12, 15, 0, 'Black', 3.5, '', '4.5', 'IMG_2367.jpg', '2014-11-08'),
('Pots', 'Plastic', 10, 11, 0, 'Black', 3, '', '4.0', 'IMG_2368.jpg', '2014-11-09'),
('Pots', 'Plastic', 5, 13, 0, 'Black', 2.5, '', '3.2', 'IMG_2369.jpg', '2014-11-11'),
('Pots', 'Plastic', 2, 5, 0, 'Black', 1.8, '', '2', 'IMG_2370.jpg', '2014-11-10'),
('Pots', 'Plastic', 1, 8, 0, 'Black', 1.25, '', '1.5', 'IMG_2371.jpg', '2014-11-10'),
('Pots', 'Plastic', 2, 9, 0, 'Black', 2, '', '2', 'IMG_2372.jpg', '2014-11-09'),
('Pots', 'Clay', 30, 20, 0, 'Brown', 4.2, '', '6', 'IMG_2373.jpg', '2014-11-10'),
('Pots', 'Clay', 500, 8, 0, 'Brown', 11, '', '11.0', 'IMG_2374.jpg', '2014-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `sf_user`
--

CREATE TABLE IF NOT EXISTS `sf_user` (
  `userId` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `userPass` varchar(50) NOT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `imgUrl` varchar(50) DEFAULT NULL,
  `jobPosition` varchar(50) DEFAULT NULL,
  `jobCompany` varchar(50) DEFAULT NULL,
  `jobAddress` varchar(50) DEFAULT NULL,
  `intrstCatg1` varchar(50) DEFAULT NULL,
  `intrstCatg2` varchar(50) DEFAULT NULL,
  `intrstCatg3` varchar(50) DEFAULT NULL,
  `Type` varchar(20) NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_user`
--

INSERT INTO `sf_user` (`userId`, `name`, `email`, `contact`, `nic`, `userPass`, `gender`, `address`, `imgUrl`, `jobPosition`, `jobCompany`, `jobAddress`, `intrstCatg1`, `intrstCatg2`, `intrstCatg3`, `Type`) VALUES
('0832ea6311bb8fe3fe43', 'Thenuka', 'thenuka@gmail.com', '0712340187', '922121211v', '090fe0d7498cd9b4e19b1b7eeab23be7d15625bf', 0, 'No:134 malcam street Colobo4', 'DSC_0021.jpg', 'CEO', 'HBO compny pvt LTD', 'No:24 main street petah', 'Roses', 'Orchid', 'Anthurium', 'admin'),
('43bf640d4b6ccc23b153', 'sanjaya', 'sanjayastn@gmail.com', '0712393188', '925486581v', '37a3f7c6294e2379ec1efd32f5b3146c8fc32e30', 0, 'NO: 45 park avenue Malabe', 'DSE230118.jpg', 'developer', 'intel cooperation', 'No: 56b seventh street Gampaha', 'Anthurium', 'decorative', 'Palms', 'admin'),
('a92de3a49089036c4029', 'ruwan', 'ruwan@gmail.com', '0774598651', '874576321v', '1bf2a3770119d3c943efdf71fc7fc337aa3a0440', 0, 'No:13 malwatta street Colobo2', 'girl-with-butterflies-vector-2616.jpg', 'Senior Advertiser', 'Manel advertising', 'NO:345c barkley road Kandy', 'Decorative Flowers', 'Hanging pots', 'Water plants', 'user'),
('d22dee9a200b6ab060f4', 'neela', 'neela@gmail.com', '0712340145', '984572561v', 'dde96c919c31797c632d3ed2b2164c3584993268', 0, 'No:13 kagalle road, Kandy', '434_6044_0.jpg', 'AGA', 'Kandy AGA office', 'AGA main branch, Kandy', 'Aglonima', 'Anthurium', 'Roses', 'user'),
('153be4f2df659f2d066f', 'sandun', 'sandun@gmail.com', '0785489822', '926583249v', '2bc1a018069c6239f591dd55d3677863d2a2415c', 0, 'No:22B Kandy road, Anuradhapura', 'teddy_bear.jpg', 'Student', 'School', 'Central Collage, Anuradhapura', 'Roses', 'Water Plants', 'Decorative ', 'user'),
('a5da6f5bc6f18a7474ce', 'dilhany', 'dilhany@gmail.com', '0716532127', '907852142v', '58d85c42578196569e4c92e960e522646e628526', 0, 'No:13 kalawana  Rathnapura', 'DSC_0312.jpg', '', '', '', '', '', '', 'user'),
('5fbd1d7252fa33b4c30d', 'kumuduni', 'kumuduni@gmail.com', '0714428921', '7565553259', '177c50c8e5fd29f2a8c96a0c6c44c50587496b19', 0, 'No:45 Arker 111 Pandulagama Anuradhapura', 'DSC_0013.jpg', '', '', '', '', '', '', 'admin'),
('9a8d629ac932764023eb', 'kumudu', 'kumudu@gmail.com', '0712340145', '807589614v', 'bdf902e649ed57fc3d6e1c63ef605bb4f3ea8fa9', 0, 'No: 22C, Galkanda, Polgahawela', 'DSCF2663.JPG', 'Sajent Major', 'SL Army', 'Nothern Camp, Airport road, Anuradapura', '', '', '', 'user'),
('41fcf77289e28cd349ac', 'nimal', 'nimal@gmail.com', '0714458978', '807589614v', 'd4ddc4af31a2e454f59efac00c02566800952374', 0, '', 'DSCF0666.JPG', '', '', '', '', '', '', 'user'),
('986a0526e09f316c1609', 'shiran', 'shiran@gmail.com', '0714485629', '8965214756', '66487cf7e30e70ed19fbb68e80f168f49d06ec4c', 0, '', 'DSCF1496.JPG', '', '', '', '', '', '', 'user'),
('2cfa35fc2f57c5226c90', 'nalin', 'nalin@gmail.com', '0714569218', '8923654781', 'b33fb75c5cb42f76002763d714280aba08bae4fb', 0, '', 'rpatzOMG.jpg', '', '', '', '', '', '', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `sf_watched`
--

CREATE TABLE IF NOT EXISTS `sf_watched` (
  `user_id` varchar(50) NOT NULL,
  `mainCatogory` varchar(50) NOT NULL,
  `subCatogory` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `plantHeight` float NOT NULL,
  `extraDetails` varchar(50) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`user_id`,`mainCatogory`,`subCatogory`,`color`,`plantHeight`,`extraDetails`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sf_watched`
--

INSERT INTO `sf_watched` (`user_id`, `mainCatogory`, `subCatogory`, `color`, `plantHeight`, `extraDetails`, `Image`, `price`) VALUES
('0832ea6311bb8fe3fe43', 'Water Plant', 'Manel', 'Bluish Purple', 1, '', 'IMG_0705.jpg', 500),
('43bf640d4b6ccc23b153', 'Water Plant', 'Manel', 'Bluish Purple', 1, '', 'IMG_0705.jpg', 500),
('43bf640d4b6ccc23b153', 'Anthurium', 'CutFlower', 'white pink nob', 3, '', 'IMG_2148.JPG', 1000),
('43bf640d4b6ccc23b153', 'Hanging', 'Fernce', 'light Green', 0.5, '', 'IMG_2247.JPG', 300),
('2cfa35fc2f57c5226c90', 'Orchid', 'Dendrobium', 'light purple', 3, '', 'IMG_0971.JPG', 650),
('0832ea6311bb8fe3fe43', 'Aglonima', 'Aglonima', 'Green/white inline', 1, '', 'IMG_2170.JPG', 200),
('2cfa35fc2f57c5226c90', 'Colias', 'Colias', 'purple/green outline', 1, '', 'IMG_2224.JPG', 250),
('2cfa35fc2f57c5226c90', 'Hanging', 'Begonia', 'Ashy green', 0.5, '', 'IMG_2257.JPG', 200);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sf_whole_table`
--
CREATE TABLE IF NOT EXISTS `sf_whole_table` (
`mainCatogory` varchar(500)
,`subCatogory` varchar(50)
,`price` double
,`stock` int(11)
,`haveFlower` tinyint(4)
,`color` varchar(50)
,`plantHeight` float
,`climateCondition` longtext
,`extraDetails` longtext
,`Image` varchar(50)
,`addedDate` date
);
-- --------------------------------------------------------

--
-- Structure for view `sf_whole_table`
--
DROP TABLE IF EXISTS `sf_whole_table`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sf_whole_table` AS (select `sf_flowers_aglonima`.`mainCatogory` AS `mainCatogory`,`sf_flowers_aglonima`.`subCatogory` AS `subCatogory`,`sf_flowers_aglonima`.`price` AS `price`,`sf_flowers_aglonima`.`stock` AS `stock`,`sf_flowers_aglonima`.`haveFlower` AS `haveFlower`,`sf_flowers_aglonima`.`color` AS `color`,`sf_flowers_aglonima`.`plantHeight` AS `plantHeight`,`sf_flowers_aglonima`.`climateCondition` AS `climateCondition`,`sf_flowers_aglonima`.`extraDetails` AS `extraDetails`,`sf_flowers_aglonima`.`Image` AS `Image`,`sf_flowers_aglonima`.`addedDate` AS `addedDate` from `sf_flowers_aglonima`) union all (select `sf_flowers_anthurium`.`mainCatogory` AS `mainCatogory`,`sf_flowers_anthurium`.`subCatogory` AS `subCatogory`,`sf_flowers_anthurium`.`price` AS `price`,`sf_flowers_anthurium`.`stock` AS `stock`,`sf_flowers_anthurium`.`haveFlower` AS `haveFlower`,`sf_flowers_anthurium`.`color` AS `color`,`sf_flowers_anthurium`.`plantHeight` AS `plantHeight`,`sf_flowers_anthurium`.`climateCondition` AS `climateCondition`,`sf_flowers_anthurium`.`extraDetails` AS `extraDetails`,`sf_flowers_anthurium`.`Image` AS `Image`,`sf_flowers_anthurium`.`addedDate` AS `addedDate` from `sf_flowers_anthurium`) union all (select `sf_flowers_colias`.`mainCatogory` AS `mainCatogory`,`sf_flowers_colias`.`subCatogory` AS `subCatogory`,`sf_flowers_colias`.`price` AS `price`,`sf_flowers_colias`.`stock` AS `stock`,`sf_flowers_colias`.`haveFlower` AS `haveFlower`,`sf_flowers_colias`.`color` AS `color`,`sf_flowers_colias`.`plantHeight` AS `plantHeight`,`sf_flowers_colias`.`climateCondition` AS `climateCondition`,`sf_flowers_colias`.`extraDetails` AS `extraDetails`,`sf_flowers_colias`.`Image` AS `Image`,`sf_flowers_colias`.`addedDate` AS `addedDate` from `sf_flowers_colias`) union all (select `sf_flowers_decorative`.`mainCatogory` AS `mainCatogory`,`sf_flowers_decorative`.`subCatogory` AS `subCatogory`,`sf_flowers_decorative`.`price` AS `price`,`sf_flowers_decorative`.`stock` AS `stock`,`sf_flowers_decorative`.`haveFlower` AS `haveFlower`,`sf_flowers_decorative`.`color` AS `color`,`sf_flowers_decorative`.`plantHeight` AS `plantHeight`,`sf_flowers_decorative`.`climateCondition` AS `climateCondition`,`sf_flowers_decorative`.`extraDetails` AS `extraDetails`,`sf_flowers_decorative`.`Image` AS `Image`,`sf_flowers_decorative`.`addedDate` AS `addedDate` from `sf_flowers_decorative`) union all (select `sf_flowers_farms`.`mainCatogory` AS `mainCatogory`,`sf_flowers_farms`.`subCatogory` AS `subCatogory`,`sf_flowers_farms`.`price` AS `price`,`sf_flowers_farms`.`stock` AS `stock`,`sf_flowers_farms`.`haveFlower` AS `haveFlower`,`sf_flowers_farms`.`color` AS `color`,`sf_flowers_farms`.`plantHeight` AS `plantHeight`,`sf_flowers_farms`.`climateCondition` AS `climateCondition`,`sf_flowers_farms`.`extraDetails` AS `extraDetails`,`sf_flowers_farms`.`Image` AS `Image`,`sf_flowers_farms`.`addedDate` AS `addedDate` from `sf_flowers_farms`) union all (select `sf_flowers_hanging`.`mainCatogory` AS `mainCatogory`,`sf_flowers_hanging`.`subCatogory` AS `subCatogory`,`sf_flowers_hanging`.`price` AS `price`,`sf_flowers_hanging`.`stock` AS `stock`,`sf_flowers_hanging`.`haveFlower` AS `haveFlower`,`sf_flowers_hanging`.`color` AS `color`,`sf_flowers_hanging`.`plantHeight` AS `plantHeight`,`sf_flowers_hanging`.`climateCondition` AS `climateCondition`,`sf_flowers_hanging`.`extraDetails` AS `extraDetails`,`sf_flowers_hanging`.`Image` AS `Image`,`sf_flowers_hanging`.`addedDate` AS `addedDate` from `sf_flowers_hanging`) union all (select `sf_flowers_orchid`.`mainCatogory` AS `mainCatogory`,`sf_flowers_orchid`.`subCatogory` AS `subCatogory`,`sf_flowers_orchid`.`price` AS `price`,`sf_flowers_orchid`.`stock` AS `stock`,`sf_flowers_orchid`.`haveFlower` AS `haveFlower`,`sf_flowers_orchid`.`color` AS `color`,`sf_flowers_orchid`.`plantHeight` AS `plantHeight`,`sf_flowers_orchid`.`climateCondition` AS `climateCondition`,`sf_flowers_orchid`.`extraDetails` AS `extraDetails`,`sf_flowers_orchid`.`Image` AS `Image`,`sf_flowers_orchid`.`addedDate` AS `addedDate` from `sf_flowers_orchid`) union all (select `sf_flowers_roses`.`mainCatogory` AS `mainCatogory`,`sf_flowers_roses`.`subCatogory` AS `subCatogory`,`sf_flowers_roses`.`price` AS `price`,`sf_flowers_roses`.`stock` AS `stock`,`sf_flowers_roses`.`haveFlower` AS `haveFlower`,`sf_flowers_roses`.`color` AS `color`,`sf_flowers_roses`.`plantHeight` AS `plantHeight`,`sf_flowers_roses`.`climateCondition` AS `climateCondition`,`sf_flowers_roses`.`extraDetails` AS `extraDetails`,`sf_flowers_roses`.`Image` AS `Image`,`sf_flowers_roses`.`addedDate` AS `addedDate` from `sf_flowers_roses`) union all (select `sf_flowers_water`.`mainCatogory` AS `mainCatogory`,`sf_flowers_water`.`subCatogory` AS `subCatogory`,`sf_flowers_water`.`price` AS `price`,`sf_flowers_water`.`stock` AS `stock`,`sf_flowers_water`.`haveFlower` AS `haveFlower`,`sf_flowers_water`.`color` AS `color`,`sf_flowers_water`.`plantHeight` AS `plantHeight`,`sf_flowers_water`.`climateCondition` AS `climateCondition`,`sf_flowers_water`.`extraDetails` AS `extraDetails`,`sf_flowers_water`.`Image` AS `Image`,`sf_flowers_water`.`addedDate` AS `addedDate` from `sf_flowers_water`) union all (select `sf_pots`.`mainCatogory` AS `mainCatogory`,`sf_pots`.`subCatogory` AS `subCatogory`,`sf_pots`.`price` AS `price`,`sf_pots`.`stock` AS `stock`,`sf_pots`.`haveFlower` AS `haveFlower`,`sf_pots`.`color` AS `color`,`sf_pots`.`plantHeight` AS `plantHeight`,`sf_pots`.`climateCondition` AS `climateCondition`,`sf_pots`.`extraDetails` AS `extraDetails`,`sf_pots`.`Image` AS `Image`,`sf_pots`.`addedDate` AS `addedDate` from `sf_pots`) union all (select `sf_fertilizer`.`mainCatogory` AS `mainCatogory`,`sf_fertilizer`.`subCatogory` AS `subCatogory`,`sf_fertilizer`.`price` AS `price`,`sf_fertilizer`.`stock` AS `stock`,`sf_fertilizer`.`haveFlower` AS `haveFlower`,`sf_fertilizer`.`color` AS `color`,`sf_fertilizer`.`plantHeight` AS `plantHeight`,`sf_fertilizer`.`climateCondition` AS `climateCondition`,`sf_fertilizer`.`extraDetails` AS `extraDetails`,`sf_fertilizer`.`Image` AS `Image`,`sf_fertilizer`.`addedDate` AS `addedDate` from `sf_fertilizer`);
